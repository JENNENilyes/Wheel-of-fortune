#include "Puzzle.h"
#include <Windows.h>



Puzzle::Puzzle()
{
    fstream f;
    f.open("words.txt",fstream::in); //r�cup�ration des  puzzles � partir du fichier texte dans un vecteur.
    string currentPhrase;
    while(getline(f,currentPhrase))
    {
        listePhrase.push_back(currentPhrase);
    }
}
void Puzzle::generatePhrase()
{
    Sleep(5000);
    system("cls") ;
    srand (time(NULL));
    phraseChiffree="";
    phrase = listePhrase[rand()%listePhrase.size()]; //s�lection al�atoire du puzzle � partir du vecteur.
    for(int i(0);i<phrase.size() ;i++)
    {
        phraseChiffree+="#"; //construction du puzzle crypt�s
    }
}
void Puzzle::afficherCaractere(string mot) //v�rification des soltuions et affichage le r�sultat.
{
    string current ="";
    int beginning_ , end_ ;
    end_ = mot.size()-1;
    if(mot == phrase)
    {
        phraseChiffree = phrase;
    }
    if(mot.size() < phrase.size())
    {
        for(int i(0);i<phrase.size();i++)
        {
            current = "";
            beginning_ = i;
            end_ = mot.size()-1 + beginning_;
            for(int j(beginning_);j<=end_;j++)
            {
                current+=phrase[j];
            }
            if(current == mot)
            {
                for(int j(beginning_);j<=end_;j++)
                {
                    phraseChiffree[j] = phrase[j];
                }
            }
        }
    }
}
int Puzzle::occurrence(string mot) //calculer le nbre d'occurence du caracteres
{
    int occ = 0;
    string current ="";
    int beginning_ , end_ ;
    end_ = mot.size()-1;
    if(mot == phrase)
    {
        return 1;
    }
    if(mot.size() < phrase.size())
    {
        for(int i(0);i<phrase.size();i++)
        {
            current = "";
            beginning_ = i;
            end_ = mot.size()-1 + beginning_;
            for(int j(beginning_);j<=end_;j++)
            {
                current+=phrase[j];
            }
            if(current == mot)
            {
                occ+=1;
            }
        }
        return occ;
    }
}
