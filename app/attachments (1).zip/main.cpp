#include <bits/stdc++.h>
#include <stdlib.h>
#include "roue.cpp"
#include "Puzzle.cpp"
#include "Player.cpp"
#include "Game.cpp"
#include <Windows.h>



using namespace std;

int main()
{
    Game myGame;
    int round (0);
    while(true)
    {
        label1:
        cout << "                                            the word to guess is : " << myGame.puzzle.phraseChiffree <<endl;
        cout << myGame.players[myGame.Current_Player].getNom() << "'s turn" << endl;
        cout << "You have : " <<myGame.players[myGame.Current_Player].getArgent() << " money" << endl;
        cout << /*"Please chose a game mode : "*/"  " << endl;
        cout << "                   1 - Guess the entire word          2 - Buy a voyelle        3 - Reveal a consonne " << endl;

        myGame.choix();
        cout << endl;
        if(myGame.mode=="1")
        {
            myGame.resoudre();
        }
        if(myGame.mode=="2")
        {
            int test = myGame.buyVoyelle();
            if(!test)
            {
                system("cls");
                cout << endl<< "   ! You Don't Have Enough Money"<<endl <<endl <<endl<<endl;
                goto label1;
            }
        }
        if(myGame.mode=="3")
        {
            myGame.consonne();
        }

        if(myGame.puzzle.phrase == myGame.puzzle.phraseChiffree)
        {
            cout << myGame.players[myGame.Current_Player].getNom() <<" won the game" <<endl;
            cout << "the word to guess was : " << myGame.puzzle.phrase <<endl;
            round+=1;
            if (round<4){
                myGame.puzzle.generatePhrase();
                myGame.Current_Player += 1;
                myGame.Current_Player %= 2;

            }


        }
        else
        {
            myGame.Current_Player += 1;
            myGame.Current_Player %= 2;
        }
    }
}







/*  ---------------------TEST Player class--------------------- */
    /*Player player1;
    cout << player1.getNom() << endl;
    cout << player1.getArgent()<< endl;
    cout << player1.getEtat()<< endl;
    player1.Pass_tour();
    cout << player1.getEtat()<< endl;
    player1.Pass_tour();
    cout << player1.score << endl<< endl<< endl<< endl;

    Puzzle test;

    test.generatePhrase();
    test.afficherCaractere("pr");

    cout << test.phrase <<endl;
    cout << test.phraseChiffree << endl;
    cout << test.occurrence("pr")<< endl;

        Roue r;

    r.generateMoney();

    cout << r.money <<endl;*/
/*
    Game test;
    test.players[test.Current_Player].setArgent(0);
    cout << test.puzzle.phraseChiffree <<endl;
    test.resoudre();
    cout << test.puzzle.phraseChiffree <<endl;
    //Player state is useless just use current_player in Game class*/
