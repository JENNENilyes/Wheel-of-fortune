#ifndef ROUE_H_INCLUDED
#define ROUE_H_INCLUDED

#include <bits/stdc++.h>

using namespace std;
class Roue
{
    private :
        vector<string> listeMoney;

    public:
        Roue();
        int money;
        void generateMoney();

};

#endif
